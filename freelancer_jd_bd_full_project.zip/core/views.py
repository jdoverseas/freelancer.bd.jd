from django.shortcuts import render, redirect
from .models import Job
from django.contrib.auth.decorators import login_required
from django import forms
from django.contrib import messages
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class JobForm(forms.ModelForm):
    class Meta:
        model = Job
        fields = ['title', 'description', 'budget']

class CustomUserCreationForm(UserCreationForm):
    username = forms.CharField(label='ইউজারনেম', max_length=150)
    email = forms.EmailField(label='ইমেইল', required=True)
    password1 = forms.CharField(label='পাসওয়ার্ড', widget=forms.PasswordInput)
    password2 = forms.CharField(label='পাসওয়ার্ড নিশ্চিত করুন', widget=forms.PasswordInput)

    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2')

def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'রেজিস্ট্রেশন সফল হয়েছে। এখন লগইন করুন।')
            return redirect('login')
    else:
        form = CustomUserCreationForm()
    return render(request, 'core/register.html', {'form': form})

@login_required
def post_job(request):
    if request.method == 'POST':
        form = JobForm(request.POST)
        if form.is_valid():
            job = form.save(commit=False)
            job.posted_by = request.user
            job.save()
            return redirect('post_job')
    else:
        form = JobForm()
    return render(request, 'core/post_job.html', {'form': form})
